function initSlider(){
    $('.gallery-slider').slick({
        autoplay: false,
        autoplaySpeed: 2000,
        dots: false,
        fade: false,
        adaptiveHeight: true,
        prevArrow: '<div class="slick-prev slick-arrow"><i class="fa fa-angle-left" aria-hidden="true"></i></div>',
        nextArrow: '<div class="slick-next slick-arrow"><i class="fa fa-angle-right" aria-hidden="true"></i></div>'
    });
    $('.testimonial-slider').slick({
        autoplay: false,
        autoplaySpeed: 2000,
        dots: false,
        fade: false,
        adaptiveHeight: true,
        prevArrow: '<div class="slick-prev slick-arrow"><i class="fa fa-angle-left" aria-hidden="true"></i></div>',
        nextArrow: '<div class="slick-next slick-arrow"><i class="fa fa-angle-right" aria-hidden="true"></i></div>'
    });
    $('.latest-slider').slick({
        autoplay: false,
        autoplaySpeed: 2000,
        dots: false,
        fade: false,
        adaptiveHeight: true,
        prevArrow: '<div class="slick-prev slick-arrow"><i class="fa fa-angle-left" aria-hidden="true"></i></div>',
        nextArrow: '<div class="slick-next slick-arrow"><i class="fa fa-angle-right" aria-hidden="true"></i></div>'
    });
    $('.gallery-1st-vid').slick({
        autoplay: false,
        autoplaySpeed: 2000,
        dots: true,
        fade: false,
        adaptiveHeight: true,
        prevArrow: '<div class="slick-prev slick-arrow"><i class="fa fa-angle-left" aria-hidden="true"></i></div>',
        nextArrow: '<div class="slick-next slick-arrow"><i class="fa fa-angle-right" aria-hidden="true"></i></div>'
    });
}

$(document).ready(function() {
    initSlider();
});
// jQuery('.grid').masonry ({
//   itemSelector: '.item',
//   columnWidth: 160
// });
    //scroll top
    //Check to see if the window is top if not then display button
   $('#scrollUp').hide();
    $(window).scroll(function () {
        height = $(this).height();
        if ($(this).scrollTop() > height) {
            $('#scrollUp').show();
        } else {
            $('#scrollUp').slideUp();
        }
    });
    //Click event to scroll to top
    height1 = 0;
    $('#scrollUp').click(function (event) {
        event.preventDefault();
        $('html, body').animate({scrollTop: height1}, 500);
        return false;
    });

        //search popup
    $(document).ready(function () {
        $('a[href="#search"]').on('click', function (event) {
            $('#search').addClass('open').addClass('animated').addClass('slideInDown');
            $('#search > form > input[type="search"]').focus();
        });
        $('#search, #search button.close').on('click keyup', function (event) {
            if (event.target == this || event.target.className == 'close' || event.keyCode == 27) {
                $(this).removeClass('open').removeClass('animated').removeClass('slideInDown');
            }
        });
    });
    $(window).scroll(function() {
   var scroll = $(window).scrollTop();
   if(scroll >= 420) {
       $('.site-nav-menu').addClass('fixed-header ').addClass('animated').addClass('fadeInDown');

   } else {
       $('.site-nav-menu').removeClass('fixed-header').removeClass('animated').removeClass('fadeInDown');
    
   }
});

    // Get the modal
var modal = document.getElementById('myModal');

// Get the image and insert it inside the modal - use its "alt" text as a caption
var img = document.getElementById('myImg');
var modalImg = document.getElementById("img01");
var captionText = document.getElementById("caption");
img.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
  captionText.innerHTML = this.alt;
}

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on <span> (x), close the modal
span.onclick = function() { 
  modal.style.display = "none";
}

