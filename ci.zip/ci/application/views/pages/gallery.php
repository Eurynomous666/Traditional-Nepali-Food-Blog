<section class="feat">
	<div class="container">
		<div class="archieve-head">
			<h3>Gallery</h3>
		</div>
		<div class="row">
			<?php foreach($gallery as $row){ ?>
			<div class="col-lg-4 connectedSortable">
				<div class="box box-solid bg-light-blue-gradient">
			        <div class="box-header">
			          <!-- /. tools -->
			          <h3 class="box-title">
			            <?php echo $row->caption;?>
			          </h3>
			        </div>
			        <!-- /.box-header -->
			        <div class="box-body no-padding border-radius-none">
			          <img src="<?php echo base_url();?>asset/images/gallery/<?php echo $row->image;?>" alt="<?php echo $row->caption;?>" id="myImg">
			        </div> 
		      	</div>
		      	<!-- The Modal -->
				<div id="myModal" class="modal">
					<span class="close">&times;</span>
					<img class="modal-content" id="img01">
					<div id="caption"></div>
				</div>
	      	</div>
	      	
			<?php } ?>
		</div>
	</div>
</section>