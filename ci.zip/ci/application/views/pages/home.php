 <section id="bricks">

   	<div class="row masonry">

   		<!-- brick-wrapper -->
         <div class="bricks-wrapper">

         	<div class="grid-sizer"></div>

         	<div class="brick entry featured-grid animate-this">
         		<div class="entry-content">
         			<div id="featured-post-slider" class="flexslider">
			   			<ul class="slides">

				   			<li>
				   				<div class="featured-post-slide">

						   			<div class="post-background" style="background-image:url('images/thumbs/featured/featured-1.jpg');"></div>

								   	<div class="overlay"></div>			   		

								   	<div class="post-content">
								   		<ul class="entry-meta">
												<li>September 06, 2016</li> 
												<li><a href="#" >Naruto Uzumaki</a></li>				
											</ul>	

								   		<h1 class="slide-title"><a href="single-standard.html" title="">Minimalism Never Goes Out of Style</a></h1> 
								   	</div> 				   					  
				   			
				   				</div>
				   			</li> <!-- /slide -->

				   			<li>
				   				<div class="featured-post-slide">

						   			<div class="post-background" style="background-image:url('images/thumbs/featured/featured-2.jpg');"></div>

								   	<div class="overlay"></div>			   		

								   	<div class="post-content">
								   		<ul class="entry-meta">
												<li>August 29, 2016</li>
												<li><a href="#">Sasuke Uchiha</a></li>					
											</ul>	

								   		<h1 class="slide-title"><a href="single-standard.html" title="">Enhancing Your Designs with Negative Space</a></h1>
						   			</div>		   				   					  
				   			
				   				</div>
				   			</li> <!-- /slide -->

				   			<li>
				   				<div class="featured-post-slide">

						   			<div class="post-background" style="background-image:url('images/thumbs/featured/featured-3.jpg');;"></div>

								   	<div class="overlay"></div>			   		

								   	<div class="post-content">
								   		<ul class="entry-meta">
												<li>August 27, 2016</li>
												<li><a href="#" class="author">Naruto Uzumaki</a></li>					
											</ul>	

								   		<h1 class="slide-title"><a href="single-standard.html" title="">Music Album Cover Designs for Inspiration</a></h1>
						   			</div>

				   				</div>
				   			</li> <!-- end slide -->

				   		</ul> <!-- end slides -->
				   	</div> <!-- end featured-post-slider -->        			
         		</div> <!-- end entry content -->         		
         	</div>
            <?php foreach($blogs as $row){?>
            	<article class="brick entry format-standard animate-this">

                  <div class="entry-thumb">
                     <a href="<?php echo base_url();?>pages/blogsingle/<?php echo $row->blog_id;?>" class="thumb-link">
   	                  <img src="<?php echo base_url();?>asset/images/blog/<?php echo $row->image;?>" alt="image">             
                     </a>
                  </div>

                  <div class="entry-text">
                  	<div class="entry-header">

                  		<div class="entry-meta">
                  			<span class="cat-links">
                  				<?php echo $row->location;?>              				
                  			</span>			
                  		</div>

                  		<h1 class="entry-title"><a href="single-standard.html"><?php echo $row->name;?></a></h1>
                  		
                  	</div>
   						<div class="entry-excerpt">
   							<?php echo $row->description;?>
   						</div>
                     <div class="entry-meta">
                        <span class="cat-links">$<?php echo $row->price; ?></span>
                     </div>
                  </div>

           		</article> <!-- end article -->
            <?php }?>

            

         </div> <!-- end brick-wrapper --> 

   	</div> <!-- end row -->

   </section> <!-- end bricks -->
