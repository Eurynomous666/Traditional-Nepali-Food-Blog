
   <section id="content-wrap" class="blog-single">
    <?php foreach($blog as $row){ ?>
    <div class="row">
      <div class="col-twelve">

        <article class="format-standard">  

          <div class="content-media">
            <div class="post-thumb">
              <img src="<?php echo base_url();?>asset/images/blog/<?php echo $row->image;?>"> 
            </div>  
          </div>

          <div class="primary-content">

            <h1 class="page-title"><?php echo $row->name;?></h1>  

            <ul class="entry-meta">
              <li class="date"><?php echo $row->location;?></li>            
              <li class="cat">$<?php echo $row->price;?></li>        
            </ul>                     
            <p class="lead"><?php echo $row->description;?></p>
          </div> <!-- end entry-primary -->              
        </article>
      </div> <!-- end col-twelve -->
    </div> <!-- end row -->
    <?php } ?>


   </section> <!-- end content -->