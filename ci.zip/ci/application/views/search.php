<div class="container">
  <div class="box box-primary">
    <div class="box-header">
      <i class="ion ion-clipboard"></i>

      <h3 class="box-title">Search Result</h3>
    </div>
    <!-- /.box-header -->
    <div class="box-body">
      <!-- See dist/js/pages/dashboard.js to activate the todoList plugin -->
      <ul class="todo-list">
        <?php foreach($search as $row){?>
        
        <li><a href="<?php echo base_url();?>pages/packagesingle/<?php echo $row->package_id;?>">
          <!-- todo text -->
          <span class="text"><?php echo $row->name;?></span></a>
          <!-- Emphasis label -->
          <small class="label label-default"><?php echo $row->trip_duration;?> Day/s</small>
          <small class="label label-danger"><?php echo $row->trip_difficulty;?></small>
          
        </li>
        
        <?php } ?>
      </ul>
    </div>
  </div>
</div>